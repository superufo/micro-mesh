-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 8.134.212.207    Database: housekeeping_service3
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sms_send_template`
--

DROP TABLE IF EXISTS `sms_send_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_send_template` (
  `sms_template_id` int unsigned NOT NULL AUTO_INCREMENT,
  `msg_type` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '消息类型\r\n1、阿姨入驻申请审核通过\r\n2、阿姨入驻申请审核拒绝\r\n3、团长入驻申请审核通过\r\n4、团长入驻申请审核拒绝\r\n5、客户在家政员详情，点击“联系阿姨”\r\n6、客户在家政员详情，点击“预约面试”\r\n7、客户取消预约\r\n8、面试成功\r\n9、客户提交签约资料后\r\n10、阿姨确认客户资料后\r\n11、客户签约电子合同后\r\n12、三方已完成电子合同签约\r\n13、三方已完成电子合同签约',
  `page` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '小程序page',
  `content` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '消息内容',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`sms_template_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_send_template`
--

LOCK TABLES `sms_send_template` WRITE;
/*!40000 ALTER TABLE `sms_send_template` DISABLE KEYS */;
INSERT INTO `sms_send_template` VALUES (1,1,'pages/Home/Home','恭喜！您的资料审核通过，点击 {{urlLink}} 打开[诸葛到家劳动者端]小程序完善简历，更快找到好工作',NULL,NULL,NULL),(2,2,'pages/Home/Home','抱歉！您的资料审核未通过，点击 {{urlLink}} 打开[诸葛到家劳动者端]小程序查看原因',NULL,NULL,NULL),(3,3,'pages/Home/Home','恭喜！您已成为团长，点击 {{urlLink}} 打开[诸葛到家团长端]开始推广赚钱',NULL,NULL,NULL),(4,4,'pages/Home/Home','抱歉！您的资料审核未通过，点击 {{urlLink}} 打开[诸葛到家团长端]小程序查看原因',NULL,NULL,NULL),(5,5,'pages/recordCommun/recordCommun','有客户（{{mobile}}）查看了您的联系方式，请尽快联系。点击 {{urlLink}} 打开[诸葛到家劳动者端]小程序查看',NULL,NULL,'2021-10-26 17:03:07'),(6,6,'pages/recordCommun/recordCommun','有客户（{{mobile}}）邀请您预约面试，请尽快联系。点击 {{urlLink}} 打开[诸葛到家劳动者端]小程序查看',NULL,NULL,NULL),(7,7,'pages/recordCommun/recordCommun','客户（{{mobile}}）已取消预约面试。点击 {{urlLink}} 打开[诸葛到家劳动者端]小程序查看',NULL,NULL,'2021-10-26 17:03:19'),(8,8,'pages/contractInform/contractInform','家政员[{{domesticName}}]邀请您填写签约信息，点击 {{urlLink}} 打开[诸葛到家家政]小程序填写',NULL,NULL,NULL),(9,9,'pages/contractInform/contractInform','客户[{{memberName}}]邀请您确认签约信息，点击 {{urlLink}} 打开[诸葛到家劳动者端]小程序确认',NULL,NULL,NULL),(10,10,'pages/contractInform/contractInform','家政员[{{domesticName}}]邀请您远程签约电子合同，点击 {{urlLink}} 打开[诸葛到家家政]小程序签约',NULL,NULL,NULL),(11,11,'pages/contractInform/contractInform','客户[{{memberName}}]已完成电子合同签约，点击 {{urlLink}} 打开[诸葛到家劳动者端]小程序查看',NULL,NULL,NULL),(12,12,'pages/contractDetail/contractDetail','恭喜您！合同签约已完成，点击 {{urlLink}} 打开[诸葛到家家政]小程序查看。感谢您选择【诸葛到家家政】，祝您生活愉快！',NULL,NULL,NULL),(13,13,'pages/contractDetail/contractDetail','恭喜您！合同签约已完成，点击 {{urlLink}} 打开[诸葛到家劳动者端]小程序查看。感谢您选择【诸葛到家家政】，祝您生活愉快！',NULL,NULL,NULL);
/*!40000 ALTER TABLE `sms_send_template` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-27 15:13:14
