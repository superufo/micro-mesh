-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 8.134.212.207    Database: housekeeping_service3
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `order_goods_scores`
--

DROP TABLE IF EXISTS `order_goods_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_goods_scores` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '评价ID',
  `order_no` bigint DEFAULT NULL COMMENT '订单编号',
  `order_goods_id` int unsigned DEFAULT NULL,
  `goods_sku_id` int unsigned NOT NULL DEFAULT '0' COMMENT 'skuID',
  `score` int DEFAULT NULL COMMENT '评分： 1,2,3,4,5',
  `img_ids` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '晒单图片id，逗号分割',
  `content` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '评价内容',
  `score0` int DEFAULT NULL COMMENT '备用，服务评分、时效评分、服务态度评分等',
  `score1` int DEFAULT NULL,
  `score2` int DEFAULT NULL,
  `score3` int DEFAULT NULL,
  `score4` int DEFAULT NULL,
  `type` int DEFAULT NULL COMMENT '类型，1：用户，2：操作员，3自动',
  `reply_content` varchar(500) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `reply_opr_id` int DEFAULT NULL COMMENT '答复操作员ID',
  `reply_at` datetime DEFAULT NULL COMMENT '答复时间',
  `opr_id` int DEFAULT NULL COMMENT '后台评论操作员ID（自评）',
  `nick_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '用户昵称',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `status` int DEFAULT NULL COMMENT '状态：0：初始状态，1：审核通过，2审核拒绝',
  `status_opr_id` int DEFAULT NULL COMMENT '删除操作员ID',
  `updated_at` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='订单商品评价表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_goods_scores`
--

LOCK TABLES `order_goods_scores` WRITE;
/*!40000 ALTER TABLE `order_goods_scores` DISABLE KEYS */;
INSERT INTO `order_goods_scores` VALUES (1,NULL,NULL,66,4,'10340','很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好很好',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'张三','2023-02-26 10:34:35',1,1,'2023-02-26 10:34:35',NULL),(2,2210072110000001,943,66,5,'10340','很好',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'张三','2023-02-26 10:34:35',0,1,'2023-02-26 10:34:35',NULL),(3,NULL,NULL,66,2,'10341,10342,10343,10344','我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'陈三','2023-02-26 16:17:08',1,1,'2023-02-26 16:17:08',NULL),(4,NULL,NULL,66,5,'10345','下雨天喜百年',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'吃鱼不突刺','2023-02-26 20:05:28',1,1,'2023-02-26 20:05:28',NULL),(5,NULL,NULL,66,5,'10346','天亮了，天凉了好歌秋',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'高歌哈','2023-02-26 20:06:06',1,1,'2023-02-26 20:06:06',NULL),(6,NULL,NULL,66,5,'10347','好好搞',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'吃饭了吗','2023-02-26 20:06:52',2,1,'2023-02-26 20:39:21',NULL),(7,NULL,NULL,66,5,'10348','评价内容评价内容评价内容评价内容',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'八岁做饭','2023-02-26 20:07:17',1,1,'2023-02-26 20:07:17',NULL),(8,NULL,NULL,66,5,'','奥帆',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'你哈撒旦','2023-02-26 20:07:46',1,1,'2023-02-26 20:07:46',NULL),(9,NULL,NULL,66,2,'10341,10342,10343,10344','9我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'陈三','2023-02-26 16:17:08',1,1,'2023-02-26 16:17:08',NULL),(10,NULL,NULL,66,2,'10341,10342,10343,10344','10我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'陈三','2023-02-26 16:17:08',1,1,'2023-02-26 16:17:08',NULL),(11,NULL,NULL,66,2,'10341,10342,10343,10344','12我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'陈三','2023-02-26 16:17:08',1,1,'2023-02-26 16:17:08',NULL),(12,NULL,NULL,66,2,'10341,10342,10343,10344','1111我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'陈三','2023-02-26 16:17:08',1,1,'2023-02-26 16:17:08',NULL),(13,NULL,NULL,66,2,'10341,10342,10343,10344','133333我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉得很不错，哈哈哈，好啊，我觉',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'陈三','2023-02-26 16:17:08',1,1,'2023-02-26 16:17:08',NULL),(14,NULL,NULL,101,3,'[10386,10387,10388]','地区额很不错很挫不',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'磨盘上的驴','2023-02-28 21:36:44',1,482965,'2023-02-28 21:36:44',NULL),(15,NULL,NULL,101,5,'[10389]','好1123',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'磨盘上的驴','2023-02-28 21:39:43',1,482965,'2023-02-28 21:39:43',NULL),(16,NULL,NULL,101,5,'10390,10391,10392','你好，你好',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'磨盘上的驴','2023-02-28 21:42:39',1,482965,'2023-02-28 21:42:39',NULL),(17,NULL,NULL,101,5,'10393,10394,10395','211312321',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'磨盘上的驴','2023-02-28 21:50:14',0,482965,'2023-02-28 21:50:14',NULL),(18,NULL,NULL,101,5,'10396,10397,10398','你好你好',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'磨盘上的驴','2023-02-28 22:11:03',0,482965,'2023-02-28 22:11:03',NULL),(19,2302272228000001,NULL,101,5,'10399,10400,10401','2132132121',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'磨盘上的驴','2023-02-28 22:13:08',0,482965,'2023-02-28 22:13:08',NULL),(20,2301012257000001,NULL,186,3,'10402,10403,10404','吃饭了吗',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'磨盘上的驴','2023-02-28 22:26:02',0,482965,'2023-02-28 22:26:02',NULL);
/*!40000 ALTER TABLE `order_goods_scores` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-27 15:39:42
