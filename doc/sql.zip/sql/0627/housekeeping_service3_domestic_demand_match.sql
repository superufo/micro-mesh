-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 8.134.212.207    Database: housekeeping_service3
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `domestic_demand_match`
--

DROP TABLE IF EXISTS `domestic_demand_match`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `domestic_demand_match` (
  `match_id` int unsigned NOT NULL AUTO_INCREMENT,
  `demand_id` int NOT NULL COMMENT '需求id',
  `domestic_user_id` int unsigned NOT NULL DEFAULT '0' COMMENT '家政员id',
  `status` tinyint(1) NOT NULL COMMENT '匹配状态，1为抢单中，2为抢单成功，3为客户签约其他阿姨/客户，4为取消需求',
  `is_look` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否查看了阿姨简历',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`match_id`) USING BTREE,
  KEY `demand_id` (`demand_id`) USING BTREE,
  KEY `domestic_user_id` (`domestic_user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='家政需求记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `domestic_demand_match`
--

LOCK TABLES `domestic_demand_match` WRITE;
/*!40000 ALTER TABLE `domestic_demand_match` DISABLE KEYS */;
INSERT INTO `domestic_demand_match` VALUES (1,3,376,1,1,'2022-03-02 17:23:17','2022-03-02 17:24:11'),(2,12,376,3,1,'2022-03-05 13:12:49','2022-03-11 17:18:04'),(3,16,1198,1,0,'2022-04-01 14:43:35','2022-04-01 14:43:35'),(4,3,409310,1,0,'2022-04-21 22:32:51','2022-04-21 22:32:51'),(5,16,271323,1,0,'2022-04-27 15:51:04','2022-04-27 15:51:04'),(6,40,480386,1,1,'2022-06-13 23:53:21','2022-08-11 12:13:33'),(7,48,480947,1,1,'2022-07-02 01:34:43','2022-07-26 15:03:51'),(8,41,480947,1,1,'2022-07-02 01:36:14','2022-07-11 01:31:23'),(9,48,481526,1,0,'2022-07-08 09:25:55','2022-07-08 09:25:55'),(10,48,263090,1,0,'2022-07-11 10:45:07','2022-07-11 10:45:07');
/*!40000 ALTER TABLE `domestic_demand_match` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-27 15:37:35
