-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 8.134.212.207    Database: housekeeping_service3
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `goods_sku_category`
--

DROP TABLE IF EXISTS `goods_sku_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `goods_sku_category` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `p_id` int unsigned NOT NULL DEFAULT '0' COMMENT '父ID',
  `sku_type` tinyint(1) NOT NULL COMMENT '类型\r\n1：订单三嫂服务费，\r\n2：订单解锁费，\r\n3：钟点服务-日常保洁，\r\n4：家电清洗，\r\n5：搬家跑腿，\r\n6：家电维修，\r\n7：亲子摄影，\r\n8：优惠特权,\r\n9:  法律咨询，\r\n10：增值服务',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '名称',
  `org_id` int unsigned NOT NULL DEFAULT '0' COMMENT '所属机构，0是通用',
  `desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '介绍',
  `sort` int unsigned NOT NULL DEFAULT '100' COMMENT '排序  值大的靠前',
  `main_img_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '主图',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_sku_category`
--

LOCK TABLES `goods_sku_category` WRITE;
/*!40000 ALTER TABLE `goods_sku_category` DISABLE KEYS */;
INSERT INTO `goods_sku_category` VALUES (0,0,0,'热门服务',0,'热门服务',10,'','2023-05-03 22:15:29',NULL,NULL),(3,0,3,'日常保洁',1,'日常保洁',9,'','2023-05-03 22:15:29',NULL,NULL),(4,0,4,'家电清洗',1,'家电清洗',8,'','2023-05-03 22:15:29',NULL,NULL),(5,0,5,'搬家跑腿',1,'搬家跑腿',7,'','2023-05-03 22:15:29',NULL,NULL),(6,0,6,'家电维修',1,'家电维修',6,'','2023-05-03 22:15:29',NULL,NULL),(10,0,10,'增值服务',1,'增值服务',5,'','2023-05-03 22:15:29',NULL,NULL),(11,3,3,'日常保洁22',1,'日常保洁22',5,'https://test-hw-obs.hcarm.com/housekeeping-service/common/20230514/a521c6ae758dddb305dd3e081eb34cd4.jpeg','2023-05-03 22:15:29','2023-05-14 23:25:15',NULL),(19,4,4,'你好',1,'',100,'https://test-hw-obs.hcarm.com/housekeeping-service/common/20230515/823cc29dfc1df2470f354cbab696aa12.jpeg','2023-05-14 21:25:29','2023-05-15 01:38:27',NULL),(20,3,3,'日常保洁33',1,'',100,'https://test-hw-obs.hcarm.com/housekeeping-service/common/20230514/c86a1d13928b8a1e792aa47c070e883a.jpeg','2023-05-14 23:25:40','2023-05-14 23:25:40',NULL);
/*!40000 ALTER TABLE `goods_sku_category` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-27 15:40:20
