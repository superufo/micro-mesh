-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 8.134.212.207    Database: housekeeping_service3
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sku_type_define`
--

DROP TABLE IF EXISTS `sku_type_define`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sku_type_define` (
  `sku_id` int DEFAULT NULL,
  `sku_type` smallint unsigned DEFAULT NULL,
  `define` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  KEY `sku_type` (`sku_type`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sku_type_define`
--

LOCK TABLES `sku_type_define` WRITE;
/*!40000 ALTER TABLE `sku_type_define` DISABLE KEYS */;
INSERT INTO `sku_type_define` VALUES (1,1,'{\"cycle\":12,\"times_by_cycle\":20}'),(14,1,'{\"cycle\":12,\"times_by_cycle\":30,\"other_service\":\"一年免费平台上自行更换阿姨\",\"other_service2\":\"首月人工匹配不超过2个阿姨\"}'),(174,1,'{\"cycle\":12,\"times_by_cycle\":30,\"other_service\":\"售后无忧(人工匹配也可以自行平台找阿姨更换)\",\"other_service2\":\"半年内专业顾问服务\"}'),(439,1,'{\"cycle\":12,\"times_by_cycle\":30,\"other_service\":\"售后无忧(人工匹配也可以自行平台找阿姨更换)\",\"other_service2\":\"享一年专业顾问服务，推荐10位（以内）阿姨\"}'),(445,1,'{\"cycle\":12,\"times_by_cycle\":20}'),(454,1,'{\"cycle\":12,\"times_by_cycle\":20}');
/*!40000 ALTER TABLE `sku_type_define` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-27 15:29:32
