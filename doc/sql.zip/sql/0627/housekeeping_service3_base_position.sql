-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 8.134.212.207    Database: housekeeping_service3
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `base_position`
--

DROP TABLE IF EXISTS `base_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `base_position` (
  `position_id` int unsigned NOT NULL AUTO_INCREMENT,
  `org_id` int unsigned NOT NULL COMMENT '组织机构id',
  `position_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '职位名称',
  `sort` mediumint unsigned NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '职位状态 1 可用  0 不可用',
  `is_predefine` tinyint unsigned NOT NULL DEFAULT '0',
  `remarks` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '备注',
  `desc` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '职位描述',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`position_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='职位表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `base_position`
--

LOCK TABLES `base_position` WRITE;
/*!40000 ALTER TABLE `base_position` DISABLE KEYS */;
INSERT INTO `base_position` VALUES (1,1,'超级管理员',100,1,1,'',NULL,NULL,NULL,NULL),(2,2,'管理员',100,1,1,'',NULL,'2021-11-01 14:16:07','2021-11-01 14:16:07',NULL),(3,1,'平台管理员',100,1,0,'','','2021-11-05 09:10:00','2022-08-05 14:05:56',NULL),(4,1,'招商运营',100,1,0,'','','2021-11-19 15:11:40','2021-11-19 15:11:49',NULL),(5,1,'运营',100,1,0,'','','2021-11-19 16:16:47','2021-11-19 16:17:11','2021-11-19 16:17:16'),(6,3,'管理员',100,1,1,'',NULL,'2021-11-26 17:18:30','2021-11-26 17:18:30',NULL),(7,2,'好阿姨销售主管',100,0,0,'','','2021-12-01 15:52:33','2021-12-01 15:53:48','2021-12-01 15:53:50'),(8,2,'线上销售',100,1,0,'','','2021-12-03 17:17:55','2021-12-03 17:44:57','2022-04-16 10:52:20'),(9,4,'管理员',100,1,1,'',NULL,'2021-12-27 14:22:43','2021-12-27 14:22:43',NULL),(10,5,'管理员',100,1,1,'',NULL,'2022-03-10 13:57:22','2022-03-10 13:57:22',NULL),(11,6,'管理员',100,1,1,'',NULL,'2022-04-12 22:23:04','2022-04-12 22:23:04',NULL),(12,1,'团长管理',100,1,0,'','','2022-04-16 10:49:07','2022-04-16 10:49:07',NULL),(13,1,'线上销售客服',100,1,0,'','','2022-04-16 10:55:59','2022-04-16 10:55:59',NULL),(14,6,'劳动者招募',100,1,0,'','','2022-04-20 10:59:47','2022-04-21 09:53:27','2022-05-03 18:23:45'),(15,6,'团长招募',100,1,0,'','','2022-04-21 09:16:45','2022-04-24 09:11:20','2022-05-03 18:23:41'),(16,6,'家政员客户团长',100,1,0,'','','2022-05-03 18:24:31','2022-05-03 18:34:18',NULL),(17,6,'劳动者运营',100,1,0,'','','2022-05-11 09:14:25','2022-05-11 09:14:25',NULL),(18,6,'销售',100,1,0,'','','2022-05-14 09:29:50','2022-06-14 10:38:40',NULL),(19,7,'管理员',100,1,1,'',NULL,'2022-05-24 22:11:08','2022-05-24 22:11:08',NULL),(20,7,'销售客服',100,1,0,'','负责客户线索的转化','2022-06-10 15:20:15','2022-06-10 15:20:15','2022-06-10 15:56:53'),(21,7,'劳动者运营',100,1,0,'','负责劳动者的招募和运营','2022-06-10 15:56:43','2022-07-16 10:55:30',NULL),(22,1,'培训客服',100,1,0,'','培训客服','2022-08-26 10:53:26','2022-08-26 10:53:26',NULL),(23,8,'管理员',100,1,1,'',NULL,'2022-09-14 18:25:25','2022-09-14 18:25:25',NULL),(24,9,'管理员',100,1,1,'',NULL,'2023-06-05 01:50:31','2023-06-05 01:50:31',NULL);
/*!40000 ALTER TABLE `base_position` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-27 15:40:25
