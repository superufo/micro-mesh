-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 8.134.212.207    Database: housekeeping_service3
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `contract_template`
--

DROP TABLE IF EXISTS `contract_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_template` (
  `template_id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '合同模版id',
  `contract_type` tinyint(1) NOT NULL COMMENT '合同类型\r\n1 家政员合同',
  `contract_type_id` int NOT NULL COMMENT '合同类型',
  `intf_code` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '合同接口类型',
  `intf_business_no` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT '接口业务编码',
  `contract_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '合同名称',
  `is_used` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '是否使用',
  `contract_config` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '合同配置',
  PRIMARY KEY (`template_id`) USING BTREE,
  KEY `domestic_service_id` (`contract_type_id`,`intf_business_no`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='家政服务合同模版';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_template`
--

LOCK TABLES `contract_template` WRITE;
/*!40000 ALTER TABLE `contract_template` DISABLE KEYS */;
INSERT INTO `contract_template` VALUES (1,1,1,'esign','5111687956','月嫂服务合同',1,'{\"templateInfo\":{\"name\":\"家政服务合同.pdf\",\"templateId\":\"f53d7d407628412c898b52839b0a7239\",\"simpleFormFields\":{\"contractNo\":\"\",\"partAName\":\"\",\"partAIdNumber\":\"\",\"partAIdMobile\":\"\",\"partAAddress\":\"\",\"partBName\":\"\",\"partBIdNumber\":\"\",\"partBIdMobile\":\"\",\"partBHometown\":\"\",\"partBGender\":\"\",\"partBAge\":\"\",\"partBEducation\":\"\",\"serviceContent\":\"\",\"serviceContentOther\":\"\",\"serviceNumber\":\"\",\"specialNeeds\":\"\",\"domesticLiveHomeType\":\"\",\"serviceStartDate\":\"\",\"serviceEndDate\":\"\",\"salary\":\"\",\"payInfo\":\"\",\"restDaysByMonth\":\"\",\"otherAgreementTerms\":\"\"}},\"createFlowOneStep\":{\"businessScene\":\"家政服务合同\",\"autoArchive\":true,\"autoInitiate\":true,\"noticeType\":\"\",\"platformAuthSign\":true,\"platformAuthSignSealId\":\"b607f01b-377b-4b05-a4f2-df39fd5610f3\"},\"signerPlatform\":{},\"signerPartA\":{\"posBean\":{\"posPage\":\"7\",\"posX\":220,\"posY\":345},\"signDateBean\":{\"format\":\"yyyy年MM月dd日\",\"posPage\":\"7\",\"posX\":140,\"posY\":290}},\"signerPartB\":{\"posBean\":{\"posPage\":\"7\",\"posX\":440,\"posY\":345},\"signDateBean\":{\"format\":\"yyyy年MM月dd日\",\"posPage\":\"7\",\"posX\":360,\"posY\":290}}}'),(2,1,2,'esign','5111687956','育儿嫂服务合同',1,'{\"templateInfo\":{\"name\":\"家政服务合同.pdf\",\"templateId\":\"f53d7d407628412c898b52839b0a7239\",\"simpleFormFields\":{\"contractNo\":\"\",\"partAName\":\"\",\"partAIdNumber\":\"\",\"partAIdMobile\":\"\",\"partAAddress\":\"\",\"partBName\":\"\",\"partBIdNumber\":\"\",\"partBIdMobile\":\"\",\"partBHometown\":\"\",\"partBGender\":\"\",\"partBAge\":\"\",\"partBEducation\":\"\",\"serviceContent\":\"\",\"serviceContentOther\":\"\",\"serviceNumber\":\"\",\"specialNeeds\":\"\",\"domesticLiveHomeType\":\"\",\"serviceStartDate\":\"\",\"serviceEndDate\":\"\",\"salary\":\"\",\"payInfo\":\"\",\"restDaysByMonth\":\"\",\"otherAgreementTerms\":\"\"}},\"createFlowOneStep\":{\"businessScene\":\"家政服务合同\",\"autoArchive\":true,\"autoInitiate\":true,\"noticeType\":\"\",\"platformAuthSign\":true,\"platformAuthSignSealId\":\"b607f01b-377b-4b05-a4f2-df39fd5610f3\"},\"signerPlatform\":{},\"signerPartA\":{\"posBean\":{\"posPage\":\"7\",\"posX\":220,\"posY\":345},\"signDateBean\":{\"format\":\"yyyy年MM月dd日\",\"posPage\":\"7\",\"posX\":140,\"posY\":290}},\"signerPartB\":{\"posBean\":{\"posPage\":\"7\",\"posX\":440,\"posY\":345},\"signDateBean\":{\"format\":\"yyyy年MM月dd日\",\"posPage\":\"7\",\"posX\":360,\"posY\":290}}}'),(3,1,3,'esign','5111687956','保姆服务合同',1,'{\"templateInfo\":{\"name\":\"家政服务合同.pdf\",\"templateId\":\"f53d7d407628412c898b52839b0a7239\",\"simpleFormFields\":{\"contractNo\":\"\",\"partAName\":\"\",\"partAIdNumber\":\"\",\"partAIdMobile\":\"\",\"partAAddress\":\"\",\"partBName\":\"\",\"partBIdNumber\":\"\",\"partBIdMobile\":\"\",\"partBHometown\":\"\",\"partBGender\":\"\",\"partBAge\":\"\",\"partBEducation\":\"\",\"serviceContent\":\"\",\"serviceContentOther\":\"\",\"serviceNumber\":\"\",\"specialNeeds\":\"\",\"domesticLiveHomeType\":\"\",\"serviceStartDate\":\"\",\"serviceEndDate\":\"\",\"salary\":\"\",\"payInfo\":\"\",\"restDaysByMonth\":\"\",\"otherAgreementTerms\":\"\"}},\"createFlowOneStep\":{\"businessScene\":\"家政服务合同\",\"autoArchive\":true,\"autoInitiate\":true,\"noticeType\":\"\",\"platformAuthSign\":true,\"platformAuthSignSealId\":\"b607f01b-377b-4b05-a4f2-df39fd5610f3\"},\"signerPlatform\":{},\"signerPartA\":{\"posBean\":{\"posPage\":\"7\",\"posX\":220,\"posY\":345},\"signDateBean\":{\"format\":\"yyyy年MM月dd日\",\"posPage\":\"7\",\"posX\":140,\"posY\":290}},\"signerPartB\":{\"posBean\":{\"posPage\":\"7\",\"posX\":440,\"posY\":345},\"signDateBean\":{\"format\":\"yyyy年MM月dd日\",\"posPage\":\"7\",\"posX\":360,\"posY\":290}}}'),(4,1,4,'esign','5111687956','钟点保姆服务合同',1,'{\"templateInfo\":{\"name\":\"家政服务合同.pdf\",\"templateId\":\"f53d7d407628412c898b52839b0a7239\",\"simpleFormFields\":{\"contractNo\":\"\",\"partAName\":\"\",\"partAIdNumber\":\"\",\"partAIdMobile\":\"\",\"partAAddress\":\"\",\"partBName\":\"\",\"partBIdNumber\":\"\",\"partBIdMobile\":\"\",\"partBHometown\":\"\",\"partBGender\":\"\",\"partBAge\":\"\",\"partBEducation\":\"\",\"serviceContent\":\"\",\"serviceContentOther\":\"\",\"serviceNumber\":\"\",\"specialNeeds\":\"\",\"domesticLiveHomeType\":\"\",\"serviceStartDate\":\"\",\"serviceEndDate\":\"\",\"salary\":\"\",\"payInfo\":\"\",\"restDaysByMonth\":\"\",\"otherAgreementTerms\":\"\"}},\"createFlowOneStep\":{\"businessScene\":\"家政服务合同\",\"autoArchive\":true,\"autoInitiate\":true,\"noticeType\":\"\",\"platformAuthSign\":true,\"platformAuthSignSealId\":\"b607f01b-377b-4b05-a4f2-df39fd5610f3\"},\"signerPlatform\":{},\"signerPartA\":{\"posBean\":{\"posPage\":\"7\",\"posX\":220,\"posY\":345},\"signDateBean\":{\"format\":\"yyyy年MM月dd日\",\"posPage\":\"7\",\"posX\":140,\"posY\":290}},\"signerPartB\":{\"posBean\":{\"posPage\":\"7\",\"posX\":440,\"posY\":345},\"signDateBean\":{\"format\":\"yyyy年MM月dd日\",\"posPage\":\"7\",\"posX\":360,\"posY\":290}}}');
/*!40000 ALTER TABLE `contract_template` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-27 15:40:15
