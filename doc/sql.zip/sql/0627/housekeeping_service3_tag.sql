-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 8.134.212.207    Database: housekeeping_service3
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag` (
  `tag_id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'tag id',
  `tag_type` int unsigned NOT NULL DEFAULT '0' COMMENT '1  三嫂服务技能\r\n2  三嫂标签',
  `tag_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'tag名称',
  `tag_status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '0 禁用 1 启用',
  `sort` int unsigned NOT NULL DEFAULT '100' COMMENT '排序',
  `is_predefine` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否预置类型',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`tag_id`) USING BTREE,
  KEY `tag_type` (`tag_type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='标签,和类型相关';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
INSERT INTO `tag` VALUES (1,1,'月子餐',1,100,1,NULL,'2021-09-22 09:24:26',NULL),(2,1,'产后修复',1,100,1,NULL,NULL,NULL),(3,1,'催乳',1,100,1,NULL,NULL,NULL),(4,1,'早产儿护理',1,100,1,NULL,NULL,NULL),(5,1,'小儿推拿',1,100,1,NULL,NULL,NULL),(6,1,'煲汤',1,100,1,NULL,NULL,NULL),(7,1,'西式餐点',1,100,1,NULL,NULL,NULL),(8,2,'老实本分',1,100,1,NULL,'2021-10-26 17:48:04',NULL),(9,2,'吃苦耐劳',1,102,1,NULL,'2021-10-26 17:47:44',NULL),(10,2,'手脚勤快',1,6667,1,NULL,'2021-10-27 10:22:53',NULL),(11,2,'普通话好',1,100,1,NULL,NULL,NULL),(12,2,'喜欢小孩',1,100,1,NULL,NULL,NULL),(13,1,'早教',1,100,1,NULL,NULL,NULL),(14,1,'辅食',1,100,1,NULL,NULL,NULL),(15,1,'新生儿疾病处理',1,100,1,NULL,NULL,NULL),(16,1,'开车',1,100,1,NULL,NULL,NULL),(17,1,'老人护理',1,100,1,NULL,NULL,NULL),(18,2,'做饭好吃',1,6668,0,'2022-06-28 10:19:40','2022-06-28 10:19:40',NULL),(19,1,'带宝宝',1,100,1,NULL,NULL,NULL),(20,1,'测试1',1,100,0,'2022-07-04 22:47:47','2022-07-04 22:47:47','2022-07-04 22:47:51'),(21,1,'测试2',1,100,0,'2022-07-04 22:48:00','2022-07-04 22:48:00','2022-07-04 22:49:15');
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-27 15:12:49
