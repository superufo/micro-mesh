-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 8.134.212.207    Database: housekeeping_service3
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `base_org`
--

DROP TABLE IF EXISTS `base_org`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `base_org` (
  `org_id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '机构id',
  `pid` int unsigned NOT NULL DEFAULT '0' COMMENT '上级机构',
  `org_code` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '机构代码',
  `org_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '机构名称',
  `org_type_id` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '机构类型\r\n1：公司(平台)，2：区域，3：代理商，4：家政企业',
  `has_children` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否存在子节点',
  `service_area_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL COMMENT '状态（0：草稿，1：待审核，2：生效，9：失效）',
  `desc` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '描述',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`org_id`) USING BTREE,
  KEY `pid` (`pid`) USING BTREE,
  KEY `service_area_id` (`service_area_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='组织机构表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `base_org`
--

LOCK TABLES `base_org` WRITE;
/*!40000 ALTER TABLE `base_org` DISABLE KEYS */;
INSERT INTO `base_org` VALUES (1,0,'0000','诸葛到家',1,1,'',2,'',NULL,'2023-06-05 01:50:21',NULL),(2,1,'0002','长沙代理',3,0,'430100',2,'','2021-11-01 14:16:07','2021-11-01 14:16:07',NULL),(3,1,'0003','金职伟业',6,0,'',2,'','2021-11-26 17:18:30','2021-11-26 17:18:30',NULL),(4,1,'0004','家政业务顾问团长',6,0,'',2,'','2021-12-27 14:22:43','2021-12-27 14:22:43',NULL),(5,1,'0005','永州诸葛到家',3,0,'431100',2,'','2022-03-10 13:57:22','2022-03-10 13:57:22',NULL),(6,1,'0006','株洲诸葛到家',3,0,'430200',2,'','2022-04-12 22:23:04','2022-04-12 22:23:04',NULL),(7,1,'0007','重庆诸葛到家',3,0,'500100',2,'','2022-05-24 22:11:08','2022-05-24 22:11:08',NULL),(8,1,'0008','承德测试',3,0,'130800',2,'','2022-09-14 18:25:20','2022-09-14 18:25:20',NULL),(9,1,'0009','岳麓区代理',3,0,'430104',2,'','2023-06-05 01:50:21','2023-06-05 01:50:21',NULL);
/*!40000 ALTER TABLE `base_org` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-27 15:35:46
