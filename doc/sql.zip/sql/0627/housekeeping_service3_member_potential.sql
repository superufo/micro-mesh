-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 8.134.212.207    Database: housekeeping_service3
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member_potential`
--

DROP TABLE IF EXISTS `member_potential`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_potential` (
  `appid` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'appid',
  `openid` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '微信openid',
  `unionid` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '微信开放平台unionid',
  `mobile` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '手机号码',
  `name` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '姓名',
  `status` tinyint DEFAULT NULL COMMENT '0:待联络；1:已联络',
  `handler_id` int unsigned NOT NULL DEFAULT '0' COMMENT '处理人ID',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='潜在客户，即在客户未注册成为会员前获取客户手机号码，以便克服电话联络';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_potential`
--

LOCK TABLES `member_potential` WRITE;
/*!40000 ALTER TABLE `member_potential` DISABLE KEYS */;
INSERT INTO `member_potential` VALUES ('wx741e3aeccbd66d2b','oG_HE4lB2cASLzTgtqzFnjj0jmSE','oYgY06LPeMXL_VTXt7G2m8hDEAgc','15084926768','刘昱',0,0,'2022-04-12 21:47:57','2022-04-18 12:11:13',NULL),('wx741e3aeccbd66d2b','oG_HE4jKlV3i74QMOMr8PlTP86T0','oYgY06IwlORSLrXGkQhn54Oo7xkQ','15570878458',NULL,0,0,'2022-04-12 21:48:57','2022-04-12 21:48:57',NULL),('wx741e3aeccbd66d2b','oG_HE4m4BIcdVu3uKd8Kj9h4qlOA','oYgY06LW19AkhqWcxphijZgw9QV8','18670350115',NULL,0,0,'2022-04-12 22:28:43','2022-04-12 22:28:43',NULL),('wx741e3aeccbd66d2b','oG_HE4ikbZM1ON0Vz_wYIUprYPv4','oYgY06Fg1UY9HPSpWcAU7vnXsMG0','15084930890','陈文辉',0,0,'2022-04-18 22:29:04','2022-04-21 00:50:49',NULL),('wx741e3aeccbd66d2b','oG_HE4mCgWB9KviIS99F5LTCwWH8','oYgY06CuRgw_SZvnJrwtOfPOos_A','18607315002',NULL,0,0,'2022-04-19 09:45:17','2022-04-19 09:45:17',NULL),('wx741e3aeccbd66d2b','oG_HE4sN3dO2EtEU7R6a9X7KoCbg','oYgY06I7U3j6RsQpF3qkwszdrLlM','15200837281',NULL,0,0,'2022-04-19 23:34:10','2022-04-19 23:34:10',NULL),('wx741e3aeccbd66d2b','oG_HE4qhXbcrTRjt9fr6aC9P5xi0','oYgY06Lx6D3lqtyPlrWt9MQNm_IA','18384112127',NULL,0,0,'2022-04-20 10:25:54','2022-04-20 10:25:54',NULL);
/*!40000 ALTER TABLE `member_potential` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-27 15:37:59
