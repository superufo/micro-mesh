-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 8.134.212.207    Database: housekeeping_service3
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sys_dict`
--

DROP TABLE IF EXISTS `sys_dict`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_dict` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `value` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '值',
  `label` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '标签',
  `type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '类型',
  `desc` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '描述',
  `sort` mediumint unsigned NOT NULL DEFAULT '100' COMMENT '排序（大值靠前）',
  `pid` int unsigned NOT NULL DEFAULT '0' COMMENT '上级id',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '备注',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_type` (`type`) USING BTREE,
  KEY `idx_value` (`value`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='字典表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_dict`
--

LOCK TABLES `sys_dict` WRITE;
/*!40000 ALTER TABLE `sys_dict` DISABLE KEYS */;
INSERT INTO `sys_dict` VALUES (1,'1','均可','domestic_live_home_type','',100,0,'',NULL,NULL,NULL),(2,'2','住家','domestic_live_home_type','',100,0,'',NULL,NULL,NULL),(3,'3','不住家','domestic_live_home_type','',100,0,'',NULL,NULL,NULL),(4,'1','待岗','domestic_work_status','',100,0,'',NULL,NULL,NULL),(5,'2','上户中','domestic_work_status','',100,0,'',NULL,NULL,NULL),(6,'3','休假','domestic_work_status','',100,0,'',NULL,NULL,NULL),(7,'0','0年','domestic_work_experience','',100,0,'',NULL,NULL,NULL),(8,'1','1年','domestic_work_experience','',110,0,'',NULL,NULL,NULL),(9,'2','2年','domestic_work_experience','',120,0,'',NULL,NULL,NULL),(10,'3','3年','domestic_work_experience','',130,0,'',NULL,NULL,NULL),(11,'4','4年','domestic_work_experience','',140,0,'',NULL,NULL,NULL),(12,'5','5年','domestic_work_experience','',150,0,'',NULL,NULL,NULL),(13,'6','6年','domestic_work_experience','',160,0,'',NULL,NULL,NULL),(14,'7','7年','domestic_work_experience','',170,0,'',NULL,NULL,NULL),(15,'8','8年','domestic_work_experience','',180,0,'',NULL,NULL,NULL),(16,'9','9年','domestic_work_experience','',190,0,'',NULL,NULL,NULL),(17,'10','10年','domestic_work_experience','',200,0,'',NULL,NULL,NULL),(18,'99','10年以上','domestic_work_experience','',210,0,'',NULL,NULL,NULL),(19,'1','女','gender','',100,0,'',NULL,NULL,NULL),(20,'2','男','gender','',100,0,'',NULL,NULL,NULL),(21,'1','汉族','nation','',1,0,'',NULL,NULL,NULL),(22,'2','蒙古族','nation','',2,0,'',NULL,NULL,NULL),(23,'3','回族','nation','',3,0,'',NULL,NULL,NULL),(24,'4','藏族','nation','',4,0,'',NULL,NULL,NULL),(25,'5','维吾尔族','nation','',5,0,'',NULL,NULL,NULL),(26,'6','苗族','nation','',6,0,'',NULL,NULL,NULL),(27,'7','彝族','nation','',7,0,'',NULL,NULL,NULL),(28,'8','壮族','nation','',8,0,'',NULL,NULL,NULL),(29,'9','布依族','nation','',9,0,'',NULL,NULL,NULL),(30,'10','朝鲜族','nation','',10,0,'',NULL,NULL,NULL),(31,'11','满族','nation','',11,0,'',NULL,NULL,NULL),(32,'12','侗族','nation','',12,0,'',NULL,NULL,NULL),(33,'13','瑶族','nation','',13,0,'',NULL,NULL,NULL),(34,'14','白族','nation','',14,0,'',NULL,NULL,NULL),(35,'15','土家族','nation','',15,0,'',NULL,NULL,NULL),(36,'16','哈尼族','nation','',16,0,'',NULL,NULL,NULL),(37,'17','哈萨克族','nation','',17,0,'',NULL,NULL,NULL),(38,'18','傣族','nation','',18,0,'',NULL,NULL,NULL),(39,'19','黎族','nation','',19,0,'',NULL,NULL,NULL),(40,'20','僳僳族','nation','',20,0,'',NULL,NULL,NULL),(41,'21','佤族','nation','',21,0,'',NULL,NULL,NULL),(42,'22','畲族','nation','',22,0,'',NULL,NULL,NULL),(43,'23','高山族','nation','',23,0,'',NULL,NULL,NULL),(44,'24','拉祜族','nation','',24,0,'',NULL,NULL,NULL),(45,'25','水族','nation','',25,0,'',NULL,NULL,NULL),(46,'26','东乡族','nation','',26,0,'',NULL,NULL,NULL),(47,'27','纳西族','nation','',27,0,'',NULL,NULL,NULL),(49,'28','景颇族','nation','',28,0,'',NULL,NULL,NULL),(50,'29','柯尔克孜族','nation','',29,0,'',NULL,NULL,NULL),(51,'30','土族','nation','',30,0,'',NULL,NULL,NULL),(52,'31','达斡尔族','nation','',31,0,'',NULL,NULL,NULL),(53,'32','仫佬族','nation','',32,0,'',NULL,NULL,NULL),(54,'33','羌族','nation','',33,0,'',NULL,NULL,NULL),(55,'34','布朗族','nation','',34,0,'',NULL,NULL,NULL),(56,'35','撒拉族','nation','',35,0,'',NULL,NULL,NULL),(57,'36','毛南族','nation','',36,0,'',NULL,NULL,NULL),(58,'37','仡佬族','nation','',37,0,'',NULL,NULL,NULL),(59,'38','锡伯族','nation','',38,0,'',NULL,NULL,NULL),(60,'39','阿昌族','nation','',39,0,'',NULL,NULL,NULL),(61,'40','普米族','nation','',40,0,'',NULL,NULL,NULL),(62,'41','塔吉克族','nation','',41,0,'',NULL,NULL,NULL),(63,'42','怒族','nation','',42,0,'',NULL,NULL,NULL),(64,'43','乌孜别克族','nation','',43,0,'',NULL,NULL,NULL),(65,'44','俄罗斯族','nation','',44,0,'',NULL,NULL,NULL),(66,'45','鄂温克族','nation','',45,0,'',NULL,NULL,NULL),(67,'46','德昂族','nation','',46,0,'',NULL,NULL,NULL),(68,'47','保安族','nation','',47,0,'',NULL,NULL,NULL),(69,'48','裕固族','nation','',48,0,'',NULL,NULL,NULL),(70,'49','京族','nation','',49,0,'',NULL,NULL,NULL),(71,'50','塔塔尔族','nation','',50,0,'',NULL,NULL,NULL),(72,'51','独龙族','nation','',51,0,'',NULL,NULL,NULL),(73,'52','鄂伦春族','nation','',52,0,'',NULL,NULL,NULL),(74,'53','赫哲族','nation','',53,0,'',NULL,NULL,NULL),(75,'54','门巴族','nation','',54,0,'',NULL,NULL,NULL),(76,'55','珞巴族','nation','',55,0,'',NULL,NULL,NULL),(77,'56','基诺族','nation','',56,0,'',NULL,NULL,NULL),(78,'1','已婚','marital_status','',100,0,'',NULL,NULL,NULL),(79,'2','未婚','marital_status','',100,0,'',NULL,NULL,NULL),(80,'3','离异','marital_status','',100,0,'',NULL,NULL,NULL),(81,'4','丧偶','marital_status','',100,0,'',NULL,NULL,NULL),(82,'1','小学','education','',100,0,'',NULL,NULL,NULL),(83,'2','初中','education','',100,0,'',NULL,NULL,NULL),(84,'3','中专','education','',100,0,'',NULL,NULL,NULL),(85,'4','职高','education','',100,0,'',NULL,NULL,NULL),(86,'5','高中','education','',100,0,'',NULL,NULL,NULL),(87,'6','大专','education','',100,0,'',NULL,NULL,NULL),(88,'7','本科','education','',100,0,'',NULL,NULL,NULL),(89,'8','研究生及以上','education','',100,0,'',NULL,NULL,NULL),(90,'1','配偶','family_relationship','',100,0,'',NULL,NULL,NULL),(91,'2','子女','family_relationship','',100,0,'',NULL,NULL,NULL),(92,'3','父母','family_relationship','',100,0,'',NULL,NULL,NULL),(93,'4','兄弟姊妹','family_relationship','',100,0,'',NULL,NULL,NULL),(94,'5','亲戚','family_relationship','',100,0,'',NULL,NULL,NULL),(95,'1','普通家务劳动','domestic_contract_service_content','',101,0,'',NULL,NULL,NULL),(96,'2','婴、幼儿照护','domestic_contract_service_content','',102,0,'',NULL,NULL,NULL),(97,'3','婴幼儿教育','domestic_contract_service_content','',103,0,'',NULL,NULL,NULL),(98,'4','产妇与新生儿护理','domestic_contract_service_content','',104,0,'',NULL,NULL,NULL),(99,'5','老人照护','domestic_contract_service_content','',105,0,'',NULL,NULL,NULL),(100,'6','病人陪护','domestic_contract_service_content','',106,0,'',NULL,NULL,NULL),(101,'7','钟点工','domestic_contract_service_content','',107,0,'',NULL,NULL,NULL),(102,'8','家庭餐制作','domestic_contract_service_content','',108,0,'',NULL,NULL,NULL),(103,'9','月嫂','domestic_contract_service_content','',109,0,'',NULL,NULL,NULL),(104,'10','管家','domestic_contract_service_content','',110,0,'',NULL,NULL,NULL),(105,'0','日','valid_term_uint','',101,0,'',NULL,NULL,NULL),(106,'1','月','valid_term_uint','',102,0,'',NULL,NULL,NULL),(107,'2','年','valid_term_uint','',103,0,'',NULL,NULL,NULL),(108,'500','500米以内','distance','',100,0,'',NULL,NULL,NULL),(109,'1000','1公里以内','distance','',100,0,'',NULL,NULL,NULL),(110,'3000','3公里以内','distance','',110,0,'',NULL,NULL,NULL),(111,'5000','5公里以内','distance','',120,0,'',NULL,NULL,NULL);
/*!40000 ALTER TABLE `sys_dict` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-27 15:39:52
