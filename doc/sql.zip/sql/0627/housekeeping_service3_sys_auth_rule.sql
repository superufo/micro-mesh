-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 8.134.212.207    Database: housekeeping_service3
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sys_auth_rule`
--

DROP TABLE IF EXISTS `sys_auth_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_auth_rule` (
  `rule_id` mediumint unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id',
  `pid` mediumint unsigned NOT NULL DEFAULT '0' COMMENT '上级规则id',
  `level` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '规则层级',
  `name` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '规则名称',
  `module` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '模块',
  `permission` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '权限字符串，用来匹配',
  `auth_type` tinyint unsigned NOT NULL DEFAULT '2' COMMENT '1:菜单权限;2:操作权限',
  `limit_org_type_ids` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '机构权限限制,公司',
  `desc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '描述',
  PRIMARY KEY (`rule_id`) USING BTREE,
  KEY `idx_module_permission` (`module`,`permission`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=174 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='会员权限规则';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_auth_rule`
--

LOCK TABLES `sys_auth_rule` WRITE;
/*!40000 ALTER TABLE `sys_auth_rule` DISABLE KEYS */;
INSERT INTO `sys_auth_rule` VALUES (1,0,1,'家政员','backend','',1,'',''),(2,1,2,'家政员管理','backend','',1,'',''),(3,2,3,'家政员资料','backend','',1,'',''),(4,3,4,'列表','backend','domestic/get-list',2,'',''),(5,3,4,'详情','backend','domestic/info',2,'',''),(6,3,4,'增加','backend','domestic/add',2,'',''),(7,3,4,'编辑','backend','domestic/edit',2,'',''),(8,3,4,'删除','backend','domestic/delete',2,'',''),(9,2,3,'家政员标签','backend','',1,'',''),(10,9,4,'列表','backend','domestic-service/get-tag-list',2,'',''),(11,9,4,'增加','backend','domestic-service/add-tag',2,'',''),(12,9,4,'编辑','backend','domestic-service/edit-tag',2,'',''),(13,9,4,'删除','backend','domestic-service/delete-tag',2,'',''),(14,1,2,'家政员入驻','backend','',1,'',''),(15,14,3,'入驻审核','backend','',1,'',''),(16,15,4,'列表','backend','domestic/get-apply-list',2,'',''),(17,15,4,'审核','backend','domestic/audit-apply',2,'',''),(18,0,1,'服务','backend','',1,'',''),(19,18,2,'三嫂服务','backend','',1,'',''),(20,19,3,'服务项目','backend','',1,'',''),(21,20,4,'列表','backend','goods-sku/get-list',2,'',''),(22,20,4,'详情','backend','goods-sku/info',2,'',''),(23,20,4,'编辑','backend','goods-sku/edit',2,'',''),(24,18,2,'基础设置','backend','',1,'',''),(25,24,3,'服务技能','backend','',1,'',''),(26,25,4,'列表','backend','domestic-service/get-skill-list',2,'',''),(27,25,4,'增加','backend','domestic-service/add-skill',2,'',''),(28,25,4,'编辑','backend','domestic-service/edit-skill',2,'',''),(29,25,4,'删除','backend','domestic-service/delete-skill',2,'',''),(30,0,1,'客户','backend','',1,'',''),(31,30,2,'客户列表','backend','',1,'',''),(32,31,3,'客户资料','backend','',1,'',''),(33,32,4,'列表','backend','member/get-list',2,'',''),(34,30,2,'线索管理','backend','',1,'',''),(35,34,3,'线索通知','backend','',1,'',''),(36,35,4,'列表','backend','member/get-clue-list',2,'',''),(37,35,4,'详情','backend','member/get-clue-info',2,'',''),(38,35,4,'历史线索','backend','member/get-clue-history-list',2,'',''),(39,0,1,'团长','backend','',1,'',''),(40,39,2,'团长管理','backend','',1,'',''),(41,40,3,'团长列表','backend','',1,'',''),(42,41,4,'列表','backend','spreader/get-list',2,'',''),(43,41,4,'详情','backend','spreader/info',2,'',''),(44,41,4,'增加','backend','spreader/add',2,'',''),(45,41,4,'编辑','backend','spreader/edit',2,'',''),(46,41,4,'删除','backend','spreader/delete',2,'',''),(47,39,2,'团长入驻','backend','',1,'',''),(48,47,3,'入驻审核','backend','',1,'',''),(49,48,4,'列表','backend','spreader/get-apply-list',2,'',''),(50,48,4,'审核','backend','spreader/audit-apply',2,'',''),(51,0,1,'订单','backend','',1,'',''),(52,51,2,'订单管理','backend','',1,'',''),(53,52,3,'合同订单','backend','',1,'',''),(54,53,4,'列表','backend','order/get-list',2,'',''),(55,53,4,'详情','backend','order/info',2,'',''),(56,0,1,'设置','backend','',1,'',''),(57,56,2,'组织架构','backend','',1,'',''),(58,57,3,'组织架构管理','backend','',1,'',''),(59,58,4,'详情','backend','org/info',2,'',''),(60,58,4,'增加','backend','org/add',2,'',''),(61,58,4,'编辑','backend','org/edit',2,'',''),(62,56,2,'权限管理','backend','',1,'',''),(63,62,3,'岗位管理','backend','',1,'',''),(64,63,4,'列表','backend','position/get-list',2,'',''),(65,63,4,'详情','backend','position/info',2,'',''),(66,63,4,'增加','backend','position/add',2,'',''),(67,63,4,'编辑','backend','position/edit',2,'',''),(68,63,4,'删除','backend','position/delete',2,'',''),(69,62,3,'角色管理','backend','',1,'',''),(70,69,4,'列表','backend','role/get-list',2,'',''),(71,69,4,'详情','backend','role/info',2,'',''),(72,69,4,'增加','backend','role/add',2,'',''),(73,69,4,'编辑','backend','role/edit',2,'',''),(74,69,4,'删除','backend','role/delete',2,'',''),(75,62,3,'用户管理','backend','',1,'',''),(76,75,4,'列表','backend','user/get-list',2,'',''),(77,75,4,'详情','backend','user/info',2,'',''),(78,75,4,'增加','backend','user/add',2,'',''),(79,75,4,'编辑','backend','user/edit',2,'',''),(80,75,4,'删除','backend','user/delete',2,'',''),(81,53,4,'查看合同','backend','order/get-contract-signed-file',2,'',''),(82,75,4,'重置密码','backend','user/reset-password',2,'',''),(83,3,4,'批量更新','backend','domestic/batch-update',2,'',''),(84,3,4,'导入家政员','backend','domestic/import',2,'',''),(85,18,2,'钟点服务','backend','',1,'',''),(86,85,3,'钟点服务','backend','',1,'',''),(87,86,4,'列表','backend','goods-sku/get-hour-service-list',2,'',''),(88,86,4,'新增','backend','goods-sku/add-hour-service',2,'',''),(89,86,4,'编辑','backend','goods-sku/edit-hour-service',2,'',''),(90,86,4,'详情','backend','goods-sku/hour-service-info',2,'',''),(91,86,4,'上下架','backend','goods-sku/set-hour-service-status',2,'',''),(92,86,4,'设置排序值','backend','goods-sku/set-hour-service-sort',2,'',''),(93,52,3,'钟点订单','backend','',1,'',''),(94,93,4,'列表','backend','order/get-hour-service-list',2,'',''),(95,93,4,'详情','backend','order/hour-service-info',2,'',''),(96,53,4,'作废合同','backend','order/void-contract',2,'',''),(97,3,4,'批量更新排序','backend','domestic/batch-update-sort',2,'',''),(98,3,4,'回访记录','backend','domestic/get-visit-list',2,'',''),(99,30,2,'需求列表','backend','',1,'',''),(100,99,3,'需求列表','backend','',1,'',''),(101,100,4,'列表','backend','demand/get-list',2,'',''),(102,100,4,'详情','backend','demand/info',2,'',''),(103,100,4,'作废','backend','demand/cancel',2,'',''),(104,100,4,'跟进','backend','demand/add-log',2,'',''),(105,53,4,'主动退款','backend','order/refund',2,'',''),(106,51,2,'售后退款','backend','',1,'',''),(107,106,3,'合同退款单','backend','',1,'',''),(108,107,4,'列表','backend','order/get-refund-list',2,'',''),(109,3,4,'新增回访记录','backend','domestic/add-visit',2,'',''),(110,31,3,'潜在客户','backend','',1,'',''),(111,110,4,'列表','backend','member/get-potential-list',2,'',''),(112,3,4,'家政员导出','backend','domestic/get-down-list',2,'',''),(113,53,4,'订单导出','backend','order/get-down-list',2,'',''),(114,56,2,'服务协议','backend','',1,'',''),(115,114,3,'用户协议','backend','',1,'',''),(116,114,3,'隐私政策','backend','',1,'',''),(117,114,3,'会员协议','backend','',1,'',''),(118,51,2,'查询统计','backend','',1,'',''),(119,118,3,'订单统计','backend','',1,'',''),(120,119,4,'统计','backend','order/stat-order',2,'',''),(121,31,3,'代理商申请','backend','',1,'',''),(122,121,4,'列表','backend','member/get-agent-apply-list',2,'',''),(123,53,4,'订单完成','backend','order/complete-service-order',2,'',''),(124,2,3,'家政员培训','backend','',1,'',''),(125,124,4,'课程申请','backend','v1/domestic/get-course-apply-list',2,'',''),(126,53,4,'退款申请','backend','order/refund-apply',2,'',''),(127,107,4,'退款审核','backend','order/refund-approval',2,'',''),(128,86,4,'促销','backend','goods-sku/set-promotion-status',2,'',''),(129,41,4,'停用/启用','backend','spreader/change-status',2,'',''),(130,53,4,'订单佣金','backend','order/commission-info',2,'',''),(131,41,4,'佣金概要','backend','spreader/commission-main',2,'',''),(132,32,4,'数据导出','backend','member/get-export-list',2,'',''),(133,20,4,'批量复制','backend','goods-sku/batch-copy',2,'',''),(134,20,4,'批量改归属','backend','goods-sku/batch-change-org',2,'',''),(135,51,2,'佣金奖励','backend','',1,'',''),(136,135,3,'佣金查询','backend','',1,'',''),(137,136,4,'列表','backend','order/commission-list',2,'',''),(138,135,3,'提现区域审核','backend','',1,'',''),(139,138,4,'列表','backend','order/withdrawal-list',2,'',''),(140,138,4,'区域审批','backend','order/withdrawal-approval',2,'',''),(141,86,4,'添加评价','backend','order/add-evaluate',2,'',''),(142,106,3,'评论管理','backend','',1,'',''),(143,142,4,'列表','backend','order/get-evaluate-list',2,'',''),(144,142,4,'审批评论','backend','order/evaluate-approval',2,'',''),(145,3,4,'阿姨退出','backend','domestic/block',2,'',''),(146,41,4,'佣金日志','backend','spreader/commission-log-list',2,'',''),(147,136,4,'财务佣金提现','backend','order/account-adjustment',4,'',''),(148,135,3,'提现财务审核','backend','',1,'',''),(149,148,4,'列表','backend','order/withdrawal-list',2,'',''),(150,148,4,'财务审批','backend','order/withdrawal-approval-final',2,'',''),(151,135,3,'提现记录','backend','',1,'',''),(152,151,4,'列表','backend','order/withdrawal-log',2,'',''),(153,135,3,'转账记录','backend','',1,'',''),(154,153,4,'列表','backend','order/wx-transfer',2,'',''),(155,153,4,'重试','backend','order/wx-transfer-re',2,'',''),(156,53,4,'解锁阿姨次数','backend','order/clue-times',2,'',''),(157,53,4,'解锁阿姨详情','backend','order/unlock-list',2,'',''),(158,153,4,'读取转账结果','backend','order/wx-transfer-read',2,'',''),(159,153,4,'转账取消','backend','order/wx-transfer-cancel',2,'',''),(160,24,3,'服务技能','backend','',1,'',''),(161,160,4,'列表','backend','domestic-service/get-category-list',2,'',''),(162,160,4,'新增','backend','domestic-service/add-category',2,'',''),(163,160,4,'编辑','backend','domestic-service/edit-category',2,'',''),(164,160,4,'删除','backend','domestic-service/delete-category',2,'',''),(165,20,4,'服务类目','backend','domestic-service/get-categorys',2,'',''),(166,135,3,'个人佣金','backend','',1,'',''),(167,166,4,'已分佣订单','backend','order/get-order-commission-list',2,'',''),(168,53,4,'人工日志列表','backend','order/get-manual-log-list',2,'',''),(169,53,4,'添加人工日志','backend','order/add-manual-log',2,'',''),(170,166,4,'全部订单','backend','order/get-order-commission-pre',2,'',''),(171,135,3,'订单佣金','backend','',1,'',''),(172,171,4,'列表','backend','order/get-order-commission-all',2,'',''),(173,86,4,'删除商品','backend','goods-sku/delete',2,'','');
/*!40000 ALTER TABLE `sys_auth_rule` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-27 15:38:03
