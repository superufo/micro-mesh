-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 8.134.212.207    Database: housekeeping_service3
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `batch_transfer_detail`
--

DROP TABLE IF EXISTS `batch_transfer_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `batch_transfer_detail` (
  `id` int NOT NULL AUTO_INCREMENT,
  `out_batch_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `out_detail_no` varchar(64) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `detail_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `user_id` int unsigned DEFAULT '0' COMMENT '用户id',
  `openid` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '微信openid',
  `user_name` varchar(128) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `transfer_amount` int DEFAULT NULL,
  `handle_date` datetime DEFAULT NULL COMMENT '任务处理时间',
  `handle_status` tinyint unsigned DEFAULT '0' COMMENT '处理状态\r\n0、待处理\r\n1、已经发送，待确认\r\n2、成功\r\n3、失败\r\n11、撤销',
  `handle_msg` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '处理结果',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_transfer_detail`
--

LOCK TABLES `batch_transfer_detail` WRITE;
/*!40000 ALTER TABLE `batch_transfer_detail` DISABLE KEYS */;
INSERT INTO `batch_transfer_detail` VALUES (1,'2303300111000001','2303300111000002',NULL,482945,'oMAtY5fH9TAp1wUsAoFDXQjEYoz0','陈文辉2',4,'2023-05-03 14:24:16',3,'转账失败,手工撤销'),(2,'2303302117000001','2303302117000002',NULL,482945,'oMAtY5fH9TAp1wUsAoFDXQjEYoz0','陈文辉2',6,'2023-05-03 14:06:05',11,'转账失败,手工撤销'),(3,'2303302123000001','2303302123000002',NULL,482945,'oMAtY5fH9TAp1wUsAoFDXQjEYoz0','陈文辉2',3,NULL,0,NULL),(4,'2303302336000001','2303302336000002',NULL,482945,'oMAtY5fH9TAp1wUsAoFDXQjEYoz0','陈文辉2',2,'2023-05-03 17:27:09',11,'转账失败,手工撤销');
/*!40000 ALTER TABLE `batch_transfer_detail` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-27 15:37:54
