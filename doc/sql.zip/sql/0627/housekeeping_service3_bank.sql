-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 8.134.212.207    Database: housekeeping_service3
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bank`
--

DROP TABLE IF EXISTS `bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bank` (
  `bank_id` int unsigned NOT NULL AUTO_INCREMENT,
  `bank_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `logo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`bank_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='银行列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank`
--

LOCK TABLES `bank` WRITE;
/*!40000 ALTER TABLE `bank` DISABLE KEYS */;
INSERT INTO `bank` VALUES (1,'中国工商银行',''),(2,'中国农业银行',''),(3,'中国银行',''),(4,'中国建设银行',''),(5,'国家开发银行',''),(6,'中国进出口银行',''),(7,'中国农业发展银行',''),(8,'交通银行',''),(9,'中信实业银行',''),(10,'中国光大银行',''),(11,'华夏银行',''),(12,'中国民生银行',''),(13,'广发银行',''),(14,'平安银行',''),(15,'招商银行',''),(16,'兴业银行',''),(17,'上海浦东发展银行',''),(18,'城市商业银行',''),(19,'农村商业银行',''),(20,'恒丰银行',''),(21,'浙商银行',''),(22,'农村合作银行',''),(23,'渤海银行',''),(24,'徽商银行股份有限公司',''),(25,'村镇银行',''),(26,'上海农商银行',''),(27,'民营银行',''),(28,'上海银行',''),(29,'城市信用社',''),(30,'农村信用社',''),(31,'中国邮政储蓄银行',''),(32,'平安银行',''),(33,'香港上海汇丰银行',''),(34,'东亚银行',''),(35,'南洋商业银行',''),(36,'恒生银行',''),(37,'中银香港',''),(38,'集友银行',''),(39,'创兴银行',''),(40,'亚洲商业银行',''),(41,'道亨银行',''),(42,'永亨银行',''),(43,'永隆银行',''),(44,'大新银行',''),(45,'花旗银行',''),(46,'美国银行',''),(47,'摩根大通银行',''),(48,'建东银行',''),(49,'美一银行',''),(50,'纽约银行',''),(51,'东京三菱银行',''),(52,'日联银行',''),(53,'三井住友银行',''),(54,'瑞穗实业银行',''),(55,'山口银行',''),(56,'韩国外换银行',''),(57,'朝兴银行',''),(58,'友利银行',''),(59,'韩国产业银行',''),(60,'新韩银行',''),(61,'韩国中小企业银行',''),(62,'韩亚银行',''),(63,'马来亚银行',''),(64,'首都银行及信托公司',''),(65,'华侨银行',''),(66,'大华银行',''),(67,'星展银行',''),(68,'盘古银行',''),(69,'泰京银行',''),(70,'泰华农民银行',''),(71,'奥地利中央合作银行',''),(72,'比利时联合银行',''),(73,'比利时富通银行',''),(74,'荷兰银行',''),(75,'荷兰商业银行',''),(76,'荷兰万贝银行',''),(77,'渣打银行',''),(78,'英国苏格兰皇家银行公众有限公司',''),(79,'法国兴业银行',''),(80,'法国巴黎银行',''),(81,'东方汇理银行',''),(82,'法国里昂信贷银行',''),(83,'法国外贸银行',''),(84,'德累斯顿银行',''),(85,'德意志银行',''),(86,'德国商业银行',''),(87,'西德意志银行',''),(88,'巴伐利亚州银行',''),(89,'德国北德意志州银行',''),(90,'中德住房储蓄银行',''),(91,'罗马银行',''),(92,'意大利联合商业银行',''),(93,'瑞士信贷第一波士顿银行',''),(94,'瑞士银行',''),(95,'丰业银行',''),(96,'蒙特利尔银行',''),(97,'澳新银行',''),(98,'葡国储蓄信贷银行',''),(99,'珠海南通银行',''),(100,'宁波国际银行',''),(101,'新联商业银行',''),(102,'协和银行',''),(103,'德富泰银行有限公司',''),(104,'荷兰合作银行（中国）有限公司',''),(105,'厦门国际银行',''),(106,'上海—巴黎国际银行',''),(107,'福建亚洲银行',''),(108,'浙江商业银行',''),(109,'华商银行',''),(110,'青岛国际银行',''),(111,'华一银行',''),(112,'中央国债登记结算有限责任公司',''),(113,'中国人民银行公开市场操作室',''),(114,'中国银行间外汇交易中心',''),(115,'城市商业银行资金清算中心',''),(116,'广州农村商业银行',''),(117,'东莞农村商业银行',''),(118,'(澳门地区)银行',''),(119,'(香港地区)银行',''),(120,'广州银联网络','');
/*!40000 ALTER TABLE `bank` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-27 15:33:08
