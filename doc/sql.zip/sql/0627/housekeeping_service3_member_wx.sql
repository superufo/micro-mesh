-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 8.134.212.207    Database: housekeeping_service3
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member_wx`
--

DROP TABLE IF EXISTS `member_wx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_wx` (
  `user_id` int unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `appid` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'appid',
  `openid` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '微信openid',
  `unionid` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '微信开放平台unionid',
  `wx_user_info` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '微信用户信息',
  `auto_sign_in` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '是否自动登录',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '更新时间',
  UNIQUE KEY `idx_open_id_app_id` (`openid`,`appid`) USING BTREE,
  KEY `idx_user_id` (`user_id`) USING BTREE,
  KEY `idx_unionid_appid` (`unionid`,`appid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='微信用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_wx`
--

LOCK TABLES `member_wx` WRITE;
/*!40000 ALTER TABLE `member_wx` DISABLE KEYS */;
INSERT INTO `member_wx` VALUES (482968,'wx06f7f6ccc728e2fd','og70m5BK2Yx_ZB2-zoQl2u165GBo','','{}',1,'2023-06-10 02:50:17','2023-06-18 23:23:47'),(0,'wx06f7f6ccc728e2fd','og70m5BK2Yx_ZB2-zoQl2u165GBoAAA','','{}',1,'2022-12-12 21:44:47','2023-06-10 02:45:58'),(482965,'wx06f7f6ccc728e2fd','og70m5BK2Yx_ZB2-zoQl2u165GBoCCC','','{}',1,'2023-06-10 02:45:58','2023-06-10 02:45:58'),(0,'wx741e3aeccbd66d2b','oG_HE4ikbZM1ON0Vz_wYIUprYPv4','oYgY06Fg1UY9HPSpWcAU7vnXsMG0','{}',1,'2022-12-11 21:32:54','2022-12-12 21:44:47'),(0,'wxc146b817b513fb71','oJxtV5c5j-NZhnOan16xUlG3C0vY','oYgY06Fg1UY9HPSpWcAU7vnXsMG012','{}',1,'2022-12-11 21:35:21','2023-01-08 15:34:15'),(482967,'wx6f3f85f17f3ad8ad','oMAtY5fH9TAp1wUsAoFDXQjEYoz0','','{}',1,'2023-06-10 02:32:18','2023-06-18 23:51:04'),(482948,'wx6f3f85f17f3ad8ad','oMAtY5fH9TAp1wUsAoFDXQjEYoz0AAA','','{}',1,'2023-06-10 02:11:14','2023-06-10 02:11:14'),(482966,'wx6f3f85f17f3ad8ad','oMAtY5fH9TAp1wUsAoFDXQjEYoz0CCC','','{}',1,'2023-06-10 02:20:05','2023-06-10 02:20:05'),(482964,'wx6f3f85f17f3ad8ad','oMAtY5fH9TAp1wUsAoFDXQjEYoz0XXX','','{}',1,'2023-01-08 15:34:15','2023-06-10 01:48:29');
/*!40000 ALTER TABLE `member_wx` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-27 15:39:32
